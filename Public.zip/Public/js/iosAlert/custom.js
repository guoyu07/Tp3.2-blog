/*globals $*/

$(function() {

	"use strict";

	prettyPrint();
	
});